# Roblox Studio Mobile — prototipo 0.1

Editor móvil experimental con interfaz oscura, escena isométrica de bloques, añadir/mover/duplicar/eliminar objetos, propiedades básicas, guardado local, exportación JSON y campo de texto Luau.

**Limitaciones:** no es Roblox Studio oficial. La vista 3D es una simulación isométrica 2D; el campo Luau no ejecuta código; el JSON no es un archivo RBXL y no publica experiencias en Roblox.

## Crear el APK usando solo tu celular
1. Abre github.com en Chrome e inicia sesión o crea una cuenta.
2. Crea un repositorio nuevo y público llamado `RobloxStudioMobile`.
3. Sube todos los archivos de este ZIP al repositorio, incluida la carpeta oculta `.github/workflows`.
4. En el repositorio abre **Actions**. Ejecuta **Build Android APK** con **Run workflow** (o espera a que termine la compilación automática al subir archivos).
5. Abre la ejecución terminada y descarga el artefacto `RobloxStudioMobile-debug-apk`.
6. Descomprime ese artefacto: dentro estará `app-debug.apk`. Instálalo en Android. Si Android lo solicita, permite instalar aplicaciones desde el navegador/gestor de archivos que usaste.

La compilación se hace en los servidores de GitHub, no en tu teléfono. No compartas tu contraseña ni tokens. GitHub puede pedir verificar la cuenta o habilitar Actions.
